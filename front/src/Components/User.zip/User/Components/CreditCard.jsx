import React from 'react';
import Grid from '@material-ui/core/Grid';

export default class CreditCard extends React.Component {
  constructor(props){
    super(props);
    this.state = {}
  }

  render(){
    return(
      <div>
      <h1>Credit Card</h1>
      </div>
    );
  }
}
