import { css } from '@emotion/core';

export default {
  navContainer: css`
    display: flex;
    margin-top: 2em;
    margin-bottom: 2em;
    align-items: center;
  `,
}
